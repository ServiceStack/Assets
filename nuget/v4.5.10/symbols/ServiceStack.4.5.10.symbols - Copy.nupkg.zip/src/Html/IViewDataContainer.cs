﻿
namespace ServiceStack.Html
{
    public interface IViewDataContainer
    {
        ViewDataDictionary ViewData { get; set; }
    }
}
