﻿
namespace ServiceStack.Html
{
	public enum TagRenderMode
	{
		Normal,
		StartTag,
		EndTag,
		SelfClosing
	}
}
