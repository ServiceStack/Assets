namespace ServiceStack.FluentValidation.Validators
{
	using System;
	using System.Threading;
	using System.Threading.Tasks;
	using ServiceStack.FluentValidation.Internal;
	using ServiceStack.FluentValidation.Resources;

	/// <summary>
	/// Asynchronous custom validator
	/// </summary>
	public class AsyncPredicateValidator : AsyncValidatorBase
	{
		private readonly Func<object, object, PropertyValidatorContext, CancellationToken, Task<bool>> predicate;

		/// <summary>
		/// Creates a new ASyncPredicateValidator
		/// </summary>
		/// <param name="predicate"></param>
		public AsyncPredicateValidator(Func<object, object, PropertyValidatorContext, CancellationToken, Task<bool>> predicate)
			: base(nameof(Messages.predicate_error), typeof(Messages))
		{
			predicate.Guard("A predicate must be specified.");
			this.predicate = predicate;
		}

		/// <summary>
		/// Runs the validation check
		/// </summary>
		/// <param name="context"></param>
		/// <param name="cancellation"></param>
		/// <returns></returns>
		protected override Task<bool> IsValidAsync(PropertyValidatorContext context, CancellationToken cancellation)
		{
			return predicate(context.Instance, context.PropertyValue, context, cancellation);
		}
	}
}