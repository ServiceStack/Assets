﻿namespace ServiceStack.Configuration
{
    public static class RoleNames
    {
        public static string Admin = "Admin";
    }
}