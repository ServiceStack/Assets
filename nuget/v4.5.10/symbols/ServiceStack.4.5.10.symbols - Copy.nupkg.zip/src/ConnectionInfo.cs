﻿namespace ServiceStack
{
    public class ConnectionInfo
    {
        public string NamedConnection { get; set; }
        public string ConnectionString { get; set; }
        public string ProviderName { get; set; }
    }
}