﻿#if !NETSTANDARD1_6
using System;
using System.Collections.Generic;

namespace ServiceStack.Platforms
{
    public partial class PlatformNet : Platform
    {
    }
}

#endif
