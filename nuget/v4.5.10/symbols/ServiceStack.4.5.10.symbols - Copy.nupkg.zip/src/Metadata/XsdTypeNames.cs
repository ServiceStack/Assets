namespace ServiceStack.Metadata
{
    internal enum XsdTypeNames
    {
        WcfTypes = 0,
        ServiceTypes = 1,
        WcfCollectionTypes = 2,
    }
}