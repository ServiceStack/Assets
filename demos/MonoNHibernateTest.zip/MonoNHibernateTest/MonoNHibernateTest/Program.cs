﻿using System;
using System.Diagnostics;
using Funq;
using NHibernate.Cfg;
using NHibernate.Impl;
using ServiceStack;
using ServiceStack.Text;

namespace MonoNHibernateTest
{
    class Program
    {
        static void Main(string[] args)
        {
            new AppHost()
                .Init()
                .Start("http://*:8080/");

            Process.Start("http://localhost:8080");
            "Press Enter to Quit...".Print();

            Console.ReadLine();
        }
    }

    public class AppHost : AppSelfHostBase
    {
        public AppHost() : base("Mono + NH Test", typeof(MyServices).Assembly) {}

        public override void Configure(Container container)
        {
            container.Register<NHibernate.ISession>(c => new MockNHibernateSession()).ReusedWithin(ReuseScope.Request);
            var session = container.Resolve<NHibernate.ISession>();
            if (session == null)
                throw new ArgumentNullException("ISession");
        }
    }

    [Route("/hello/{Name}")]
    public class Hello
    {
        public string Name { get; set; }
    }

    public class MyServices : Service
    {
        public object Any(Hello request)
        {
            return request;
        }
    }
}
